/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import javax.xml.bind.SchemaOutputResolver;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * 
 * QueryRunner takes a list of Queries that are initialized in it's constructor
 * and provides functions that will call the various functions in the QueryJDBC class 
 * which will enable MYSQL queries to be executed. It also has functions to provide the
 * returned data from the Queries. Currently the eventHandlers in QueryFrame call these
 * functions in order to run the Queries.
 */
public class QueryRunner {

    
    public QueryRunner()
    {
        this.m_jdbcData = new QueryJDBC();
        m_updateAmount = 0;
        m_queryArray = new ArrayList<>();
        m_error="";
    
        
        // TODO - You will need to change the queries below to match your queries.
        
        // You will need to put your Project Application in the below variable
        
        this.m_projectTeamApplication="Popcorn is tasty";    // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        
        // Each row that is added to m_queryArray is a separate query. It does not work on Stored procedure calls.
        // The 'new' Java keyword is a way of initializing the data that will be added to QueryArray. Please do not change
        // Format for each row of m_queryArray is: (QueryText, ParamaterLabelArray[], LikeParameterArray[], IsItActionQuery, IsItParameterQuery)
        
        //    QueryText is a String that represents your query. It can be anything but Stored Procedure
        //    Parameter Label Array  (e.g. Put in null if there is no Parameters in your query, otherwise put in the Parameter Names)
        //    LikeParameter Array  is an array I regret having to add, but it is necessary to tell QueryRunner which parameter has a LIKE Clause. If you have no parameters, put in null. Otherwise put in false for parameters that don't use 'like' and true for ones that do.
        //    IsItActionQuery (e.g. Mark it true if it is, otherwise false)
        //    IsItParameterQuery (e.g.Mark it true if it is, otherwise false)

        //PARMS ?
        //likeparms ? CONTAINS A LIKE OTHERWISE FALSE
        //ACTION ? INSERT, UPDATE, DELETE OTHERWSIE FALSE

        m_queryArray.add(new QueryData("SELECT movie.title, director.first_name, director.last_name FROM movie_direct JOIN movie USING (movie_id) JOIN director USING (director_id) WHERE director.first_name = 'Joss' AND director.last_name = 'Whedon';", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT movie.movie_id, movie.title, count(director.director_id) as `director number` FROM movie_direct JOIN movie USING (movie_id) JOIN director USING (director_id) GROUP BY movie.movie_id HAVING `director number` > 1;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT movie_id, title, length_mins as 'Runtime' FROM movie ORDER BY length_mins desc limit 3;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT movie.title, movie.Length_mins, movie.Release_Year, ROUND(AVG(rating.rating),2) As `average rating`, director.First_name, director.Last_name FROM Movie_direct JOIN movie USING (movie_id) JOIN director USING (director_id) NATURAL JOIN rating GROUP BY movie.title HAVING movie.title LIKE '%avengers%' ORDER BY movie.Release_Year DESC;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT movie.movie_id, movie.title, showing.show_date, theatreHasRoom.room_code FROM movie NATURAL JOIN showing JOIN theatreHasRoom ON showing.theatreHasRoom_id = theatreHasRoom.theatreHasRoom_id WHERE theatreHasRoom.room_code = 'VIP' AND showing.show_date LIKE '2019%' ORDER BY showing.show_date;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT showing.show_date, movie.title, movie.Length_mins, theatre.theatre_name, theatre.theatre_address, theatre_state FROM showing INNER JOIN movie ON showing.movie_id=movie.movie_id NATURAL JOIN theatrehasroom JOIN theatre ON theatrehasroom.theatre_id=theatre.theatre_id WHERE showing.show_date BETWEEN '2019-11-15' AND '2019-11-21' ORDER BY show_date ASC;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT showing.showing_id AS `ID`, showing.show_date AS `Show Date`, showing.show_time AS `Show Time`, movie.title AS `Movie Title`, COUNT(ticket_id) AS `Number of Tickets Sold`, SUM(ticket_price) AS `Total Sales` FROM ticket JOIN showing USING (showing_id) JOIN movie USING (movie_id) GROUP BY showing.showing_id ORDER BY `Total Sales` DESC, showing.showing_id;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT showing.showing_id AS `Showing ID`, showing.show_date AS `Date`, showing.show_time AS `Time`, ABS(theatrehasroom.room_capacity - COUNT(ticket.ticket_id)) AS `Available Seats` FROM showing JOIN theatrehasroom USING (theatrehasroom_id) NATURAL JOIN ticket GROUP BY showing.showing_id ORDER BY `Available Seats` showing.showing_id;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT showing.show_date as `showing date`, showing.show_time as `showing time`, movie.movie_id as `movie id`, movie.title as `movie title`, SUM(ticket.ticket_price) AS `total sales` FROM ticket INNER JOIN showing ON ticket.showing_id = showing.showing_id INNER JOIN movie ON movie.movie_id = showing.movie_id GROUP BY showing.show_date, showing.show_time, movie.movie_id;", new String [] {}, new boolean[] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT movie.title as `Title`, ROUND(AVG(rating.rating),2) as `Average Rating` FROM movie NATURAL JOIN rating GROUP BY movie.movie_id ORDER BY `Average Rating` DESC;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("SELECT movie.movie_id as `ID`, movie.title as `Title`, COUNT(rating_id) as `Number of Ratings` FROM movie NATURAL JOIN rating GROUP BY movie.movie_id ORDER BY `Number of Ratings` DESC;", new String [] {}, new boolean [] {false}, false, false));
        m_queryArray.add(new QueryData("INSERT INTO user VALUES(?,?,?,?,?);", new String [] {"user_id", "user_fname", "user_lname", "user_email", "user_birthdate"}, new boolean[] {false}, true, true));
        m_queryArray.add(new QueryData("INSERT INTO movie VALUES(?,?,?,?,?);", new String [] {"movie_id", "title", "Release_Year", "Length_mins", "Movie_country"}, new boolean[] {false}, true, true));
    }
       

    public int GetTotalQueries()
    {
        return m_queryArray.size();
    }
    
    public int GetParameterAmtForQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetParmAmount();
    }
              
    public String  GetParamText(int queryChoice, int parmnum )
    {
       QueryData e=m_queryArray.get(queryChoice);        
       return e.GetParamText(parmnum); 
    }   

    public String GetQueryText(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetQueryString();        
    }
    
    /**
     * Function will return how many rows were updated as a result
     * of the update query
     * @return Returns how many rows were updated
     */
    
    public int GetUpdateAmount()
    {
        return m_updateAmount;
    }
    
    /**
     * Function will return ALL of the Column Headers from the query
     * @return Returns array of column headers
     */
    public String [] GetQueryHeaders()
    {
        return m_jdbcData.GetHeaders();
    }
    
    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     * @return multi-dimensional array of String data based on the resultset 
     * from the query
     */
    public String[][] GetQueryData()
    {
        return m_jdbcData.GetData();
    }

    public String GetProjectTeamApplication()
    {
        return m_projectTeamApplication;        
    }
    public boolean  isActionQuery (int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryAction();
    }
    
    public boolean isParameterQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryParm();
    }
    
     
    public boolean ExecuteQuery(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteQuery(e.GetQueryString(), parms, e.GetAllLikeParams());
        return bOK;
    }
    
     public boolean ExecuteUpdate(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteUpdate(e.GetQueryString(), parms);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        return bOK;
    }   
    
      
    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase)
    {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (bConnect == false)
            m_error = m_jdbcData.GetError();        
        return bConnect;
    }
    
    public boolean Disconnect()
    {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (bConnect == false)
            m_error = m_jdbcData.GetError();
        return true;
    }
    
    public String GetError()
    {
        return m_error;
    }
 
    private QueryJDBC m_jdbcData;
    private String m_error;    
    private String m_projectTeamApplication;
    private ArrayList<QueryData> m_queryArray;  
    private int m_updateAmount;
            
    /**
     * @param args the command line arguments
     */
    

    public static void main(String[] args) {
        //TODO code application logic here

        final QueryRunner queryrunner = new QueryRunner();
        
        if (args.length == 0)
        {
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {

                    QueryFrame frame = new QueryFrame(queryrunner);
                    frame.setVisible(true);

                }            
            });
        }
        else
        {
            if (args[0].equals ("-console")) {
                String [] descriptions = {
                    "Get the movie(s) directed by Joss Whedon",
                        "Get all the movies with more than 1 director",
                        "Get the top 3 longest movies by Runtime",
                        "Find out the director for the avengers series and get the average rating of the movie",
                        "Get the movies that played in VIP rooms during 2019",
                        "Find out the movie whose showing time is between 2019/11/15~2019/11/21 and in which theatre",
                        "Get the number of tickets sold and the total value of each showing, ordered by profit and showing id",
                        "Get the number of available seats for each showing, ordered by available seats and showing id",
                        "Get the total sales for each movie showing",
                        "Get the highest rated movies (from everyone)",
                        "Get the movies with the largest number of ratings",
                        "Add a new user",
                        "Add a new movie"
                };

                String host;
                String user;
                String pass;
                String db;

                Scanner sc = new Scanner(System.in);
                System.out.print("Enter host: ");
                host = sc.nextLine();
                System.out.println();

                System.out.print("Enter username: ");
                user = sc.nextLine();
                System.out.println();

                System.out.print("Enter password: ");
                pass = sc.nextLine();
                System.out.println();

                System.out.print("Enter the database name: ");
                db = sc.nextLine();
                System.out.println();

                if (queryrunner.Connect(host, user, pass, db)) {

                    int numQueries = queryrunner.GetTotalQueries();

                    boolean querying = true;

                    while (querying) {

                        //Print menu
                        int numChoices = queryrunner.m_queryArray.size();
                        System.out.println("Select a Query from the following: ");
                        System.out.print("--------------------------------------\n");
                        for (int i = 0; i < numChoices; i++) {
                            String text = queryrunner.GetQueryText(i); //Unused!
                            String description = descriptions[i];
                            System.out.print("-- " + (i + 1) + ") " + description + "\n");
                        }
                        System.out.print("-- " + (numChoices + 1) + ") Quit\n");
                        System.out.print("--------------------------------------\n");
                        int choice = Integer.parseInt(sc.nextLine()) - 1;

                        if (choice != (numChoices)) {

                            QueryData current = queryrunner.m_queryArray.get(choice);

                            if (current.IsQueryAction()) {
                                //Insert statements
                                int numParams = queryrunner.GetParameterAmtForQuery(choice);
                                String[] values = new String[numParams];

                                for (int i = 0; i < numParams; i++) {
                                    System.out.print("Enter the value for " + queryrunner.GetParamText(choice, i) + ": ");
                                    String value = sc.nextLine();
                                    values[i] = value;
                                }

                                try {
                                    queryrunner.ExecuteUpdate(choice, values);
                                    int numRowsAffected = queryrunner.GetUpdateAmount();

                                    if (numRowsAffected != 0) {
                                        System.out.println("Action confirmed, " + numRowsAffected + " affected.");
                                    } else {
                                        System.out.println("Action failed, try again.");
                                    }

                                } catch (Exception e) {
                                    System.out.println(e);
                                }
                            }

                            if (current.IsQueryParm()) {
                                //Has parameters
                                int numParams = current.GetParmAmount();
                                String[] parameters = new String[numParams];

                                for (int j = 0; j < numParams; j++) {
                                    String label = current.GetParamText(j);
                                    System.out.print("Enter value for " + label + ": ");
                                    String param = sc.nextLine();
                                    parameters[j] = param;
                                }

                                try {
                                    queryrunner.ExecuteQuery(choice, parameters);

                                    String[] labels = queryrunner.GetQueryHeaders();
                                    String[][] result = queryrunner.GetQueryData();
                                    int numCol = labels.length;
                                    int numRow = result.length;
                                    int[] longestDataOfEachCol = new int[numCol];

                                    for (int col = 0; col < numCol; col++) {
                                        int currMax = 0;
                                        for (int row = 0; row < numRow; row++) {
                                            int curr = result[row][col].length();
                                            if (curr > currMax) {
                                                currMax = curr;
                                            }
                                        }
                                        longestDataOfEachCol[col] = currMax;
                                    }

                                    //If label is longer than data... use label length
                                    for (int i = 0; i < numCol; i++) {
                                        if (labels[i].length() > longestDataOfEachCol[i]) {
                                            longestDataOfEachCol[i] = labels[i].length();
                                        }
                                    }

                                    //Print Column Labels
                                    for (int i = 0; i < numCol; i++) {
                                        System.out.printf("| %-" + longestDataOfEachCol[i] + "s ", labels[i]);
                                    }
                                    System.out.print("|");
                                    System.out.println();

                                    String bar = "";
                                    int sum = 0;
                                    for (int i = 0; i < longestDataOfEachCol.length; i++) {
                                        sum += longestDataOfEachCol[i];
                                    }
                                    int whitespaces = (longestDataOfEachCol.length * 3) + 1;
                                    for (int i = 0; i < sum + whitespaces; i++) {
                                        bar += "-";
                                    }

                                    //Print solid line
                                    System.out.println(bar);

                                    //Print data
                                    for (int row = 0; row < numRow; row++) {
                                        for (int col = 0; col < numCol; col++) {
                                            System.out.printf("| %-" + longestDataOfEachCol[col] + "s ", result[row][col]);
                                        }
                                        System.out.print("|");
                                        System.out.println();
                                    }

                                    System.out.println();


                                } catch (Exception e) {
                                    System.out.println(e);
                                }

                            } else {
                                try {
                                    queryrunner.ExecuteQuery(choice, new String[] {}); //No params

                                    String[] labels = queryrunner.GetQueryHeaders();
                                    String[][] result = queryrunner.GetQueryData();
                                    int numCol = labels.length;
                                    int numRow = result.length;
                                    int[] longestDataOfEachCol = new int[numCol];

                                    for (int col = 0; col < numCol; col++) {
                                        int currMax = 0;
                                        for (int row = 0; row < numRow; row++) {
                                            int curr = result[row][col].length();
                                            if (curr > currMax) {
                                                currMax = curr;
                                            }
                                        }
                                        longestDataOfEachCol[col] = currMax;
                                    }

                                    //If label is longer than data... use label length
                                    for (int i = 0; i < numCol; i++) {
                                        if (labels[i].length() > longestDataOfEachCol[i]) {
                                            longestDataOfEachCol[i] = labels[i].length();
                                        }
                                    }

                                    //Print Column Labels
                                    for (int i = 0; i < numCol; i++) {
                                        System.out.printf("| %-" + longestDataOfEachCol[i] + "s ", labels[i]);
                                    }
                                    System.out.print("|");
                                    System.out.println();

                                    String bar = "";
                                    int sum = 0;
                                    for (int i = 0; i < longestDataOfEachCol.length; i++) {
                                        sum += longestDataOfEachCol[i];
                                    }
                                    int whitespaces = (longestDataOfEachCol.length * 3) + 1;
                                    for (int i = 0; i < sum + whitespaces; i++) {
                                        bar += "-";
                                    }

                                    //Print solid line
                                    System.out.println(bar);

                                    //Print data
                                    for (int row = 0; row < numRow; row++) {
                                        for (int col = 0; col < numCol; col++) {
                                            System.out.printf("| %-" + longestDataOfEachCol[col] + "s ", result[row][col]);
                                        }
                                        System.out.print("|");
                                        System.out.println();
                                    }

                                    System.out.println();
                                } catch (Exception e) {
                                    System.out.println(e);
                                }
                            }
                        } else {
                            querying = false;
                        }
                    }

                    System.out.println("Thank you for using QueryRunner console!");
                    queryrunner.Disconnect();
                } else {
                    System.out.println("Failed to connect to the database, please try again.");
                }
            }

                // You should code the following functionality:

                //    You need to determine if it is a parameter query. If it is, then
                //    you will need to ask the user to put in the values for the Parameters in your query
                //    you will then call ExecuteQuery or ExecuteUpdate (depending on whether it is an action query or regular query)
                //    if it is a regular query, you should then get the data by calling GetQueryData. You should then display this
                //    output. 
                //    If it is an action query, you will tell how many row's were affected by it.
                // 
                //    This is Psuedo Code for the task:

                //    for (i=0;i < n; i++)
                //    {
                //       Is it a query that Has Parameters
                //       Then
                //           amt = find out how many parameters it has
                //           Create a paramter array of strings for that amount
                //           for (j=0; j< amt; j++)
                //              Get The Paramater Label for Query and print it to console. Ask the user to enter a value
                //              Take the value you got and put it into your parameter array
                //           If it is an Action Query then
                //              call ExecuteUpdate to run the Query
                //              call GetUpdateAmount to find out how many rows were affected, and print that value
                //           else
                //               call ExecuteQuery 
                //               call GetQueryData to get the results back
                //               print out all the results
                //           end if
                //      }
                //    Disconnect()


                // NOTE - IF THERE ARE ANY ERRORS, please print the Error output
                // NOTE - The QueryRunner functions call the various JDBC Functions that are in QueryJDBC. If you would rather code JDBC
                // functions directly, you can choose to do that. It will be harder, but that is your option.
                // NOTE - You can look at the QueryRunner API calls that are in QueryFrame.java for assistance. You should not have to 
                //    alter any code in QueryJDBC, QueryData, or QueryFrame to make this work.
        }
 
    }    
}
